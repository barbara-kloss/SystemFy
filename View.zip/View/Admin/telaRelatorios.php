<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios</title>
    <link rel="stylesheet" href="/css/telaRelatorios.css">
    <link href="https://fonts.googleapis.com/css2?family=Alata&family=Akshar:wght@700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.5.1/jspdf.umd.min.js"></script> 
</head>

<body>
    <div class="background">
        <div class="bolinha bolinha1"></div>
        <div class="bolinha bolinha2"></div>
        <div class="bolinha bolinha3"></div>
        <div class="bolinha bolinha4"></div>
        <div class="bolinha bolinha5"></div>
        <div class="bolinha bolinha6"></div>

        <div class="logoCantoInferior">
            <img src="/imgFy/logoSemfundoEscritaBranca.png" alt="Logo">
        </div>

        <div class="logoWhatsApp">
            <img src="/imgFy/whatsapp (3).png" alt="logoWhatsApp">
        </div>

        <div class="fundoSemiTransparente">

            <div class="main-content-grid">

                <div class="navBar">
                    <nav>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="/admin">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="/admin/menu/list">Nutricional</a>
                            </li>
                            <li class="nav-item">
                                <a href="/admin/exercise/list">Treinos</a>
                            </li>
                            <li class="nav-item">
                                <a href="/cadastro">Clientes</a>
                            </li>
                            <li class="nav-item">
                                <a href="/admin/report/list" class="active">Relatorios</a>
                            </li>
                            <li class="nav-item">
                                <a href="/admin/plano/list">Planos</a>
                        </ul>
                    </nav>
                </div>

                <div class="profile-box-container">
                    <a href="/admin/cadastro" class="profile-link">
                        <div class="cardVerPerfil"> <i class="fas fa-user"></i> </div>
                        <div class="textocardVerPerfil"> Ver perfil </div>
                    </a>
                </div>

                <div class="content-cards-wrapper">

    <h2 class="section-title">Escolha o Tipo de Relatório</h2>

    <div class="relatorio-card">
        <i class="fas fa-users card-icon"></i>
        <h4 class="card-title">Clientes</h4>
        <h4 class="card-description">Relatorio de Clientes Ativos</h4>
        
        <div class="export-options">
            <button class="btn-export" data-export="pdf"><i class="fas fa-file-pdf"></i> PDF</button>
            <button class="btn-export" data-export="csv"><i class="fas fa-file-csv"></i> CSV</button>
        </div>
    </div>

    <div class="relatorio-card">
        <i class="fas fa-dollar-sign card-icon"></i>
        <h3 class="card-title">Faturamento</h3>
        <h4 class="card-description">Relatorio de Faturamento</h4>

        
        <div class="export-options">
            <button class="btn-export" data-export="pdf"><i class="fas fa-file-pdf"></i> PDF</button>
            <button class="btn-export" data-export="csv"><i class="fas fa-file-csv"></i> CSV</button>
        </div>
    </div>

    <div class="relatorio-card">
        <i class="fas fa-calendar-alt card-icon"></i>
        <h3 class="card-title">Agenda</h3>
        <h4 class="card-description">Relatorio de Agenda</h4>

        
        <div class="export-options">
            <button class="btn-export" data-export="pdf"><i class="fas fa-file-pdf"></i> PDF</button>
            <button class="btn-export" data-export="csv"><i class="fas fa-file-csv"></i> CSV</button>
        </div>
    </div>

</div>
        </div>
    </div>

 <script>
    document.addEventListener('DOMContentLoaded', function() {
        const exportButtons = document.querySelectorAll('.btn-export');
        const { jsPDF } = window.jspdf; 

        // Função para simular o download de um arquivo (usada para CSV)
        function simulateTextDownload(filename, text, mimeType) {
            const element = document.createElement('a');
            element.setAttribute('href', `data:${mimeType};charset=utf-8,${encodeURIComponent(text)}`);
            element.setAttribute('download', filename);
            
            element.style.display = 'none';
            document.body.appendChild(element);

            element.click(); 

            document.body.removeChild(element); 
        }

        // 1. Lógica dos Botões de Exportação (PDF/CSV)
        exportButtons.forEach(button => {
            button.addEventListener('click', function() {
                const format = this.getAttribute('data-export');
                const card = this.closest('.relatorio-card');
                const type = card.querySelector('.card-title').textContent.trim();
                
                // CORREÇÃO: Removemos a tentativa de buscar .card-description que não existe.
                const description = `Dados detalhados do relatório de ${type}.`; 

                const now = new Date().toLocaleDateString('pt-BR'); 
                let fileName = `Relatorio_${type.replace(/\s/g, '')}_${new Date().toISOString().slice(0, 10)}`;
                
                if (format === 'csv') {
                    // Conteúdo CSV real
                    let csvContent = "ID,Nome/Mês,Status,Valor\n";
                    csvContent += "1,Cliente A,Ativo,R$ 150,00\n";
                    csvContent += "2,Cliente B,Ativo,R$ 200,00\n";
                    csvContent += "3,Cliente C,Inativo,R$ 0,00\n";

                    alert(`Preparando exportação de ${type} como CSV...`);
                    simulateTextDownload(fileName + '.csv', csvContent, 'text/csv');

                } else if (format === 'pdf') {
                    
                    if (typeof jsPDF !== 'undefined') {
                        alert(`Gerando PDF  para ${type}...`);
                        
                        const doc = new jsPDF();
                        const title = `Relatório de ${type}`;
                        
                        // ESTRUTURAÇÃO TESTE
                        const head = [["ID", "Nome/Compromisso", "Status", "Valor/Data"]];
                        let body = [];

                        if (type === "Clientes") {
                             body = [
                                 ["1", "João Silva", "Ativo", "R$ 150,00"],
                                 ["2", "Maria Santos", "Ativo", "R$ 200,00"],
                                 ["3", "Pedro Souza", "Inativo", "R$ 0,00"]
                             ];
                        } else if (type === "Faturamento") {
                            body = [
                                ["Mensal Previsto", "---", "Ativo", "R$ 350,00"],
                                ["Anual (Estimado)", "---", "---", "R$ 4.200,00"]
                            ];
                        } else if (type === "Agenda") {
                            body = [
                                ["4", "Treino c/ João", "Confirmado", "25/Dez 10:00"],
                                ["5", "Consulta Nutri", "Pendente", "26/Dez 14:00"]
                            ];
                        }


                        // Configuração do PDF (Estilo Básico)
                        doc.setFont('helvetica', 'bold');
                        doc.setFontSize(18);
                        doc.setTextColor(42, 42, 42); 
                        doc.text(title, 105, 20, null, null, "center");
                        
                        doc.setFontSize(10);
                        doc.setFont('helvetica', 'normal');
                        doc.setTextColor(102, 102, 102);
                        // Usando a descrição corrigida:
                        doc.text(`Descrição: ${description}`, 20, 30, { maxWidth: 170 });
                        doc.text(`Gerado em: ${now}`, 190, 10, null, null, "right");
                        
                        // Geração da Tabela (Você deve incluir o CDN de jspdf-autotable para isso funcionar)
                        if (typeof doc.autoTable === 'function') {
                            doc.autoTable({
                                head: head,
                                body: body,
                                startY: 40,
                                theme: 'striped', 
                                headStyles: { fillColor: [42, 42, 42], textColor: 255 }, 
                                styles: { cellPadding: 3, fontSize: 10 },
                                columnStyles: { 3: { halign: 'right' } } 
                            });
                        } else {
                            // Fallback Simples se autoTable não estiver disponível
                            let y = 45;
                            doc.setFontSize(12);
                            doc.text("Dados de Exemplo (Instale o plugin jspdf-autotable para melhor visualização):", 20, y);
                            y += 8;
                            head[0].forEach((h, i) => doc.text(h, 20 + i * 40, y));
                            y += 5;
                            doc.setLineWidth(0.5);
                            doc.line(20, y, 190, y);
                            y += 5;
                            body.forEach(row => {
                                row.forEach((cell, i) => doc.text(cell, 20 + i * 40, y));
                                y += 7;
                            });
                        }

                        doc.save(fileName + '.pdf'); 

                    } else {
                        alert("ERRO: A biblioteca jsPDF não está pronta. Certifique-se de que os CDNs da jsPDF e do jspdf-autotable foram incluídos corretamente no <head>.");
                    }
                }
            });
        });
    });
</script>
</body>
</html>