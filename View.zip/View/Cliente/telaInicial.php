<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home</title>
    <link rel="stylesheet" href="/css/telaInicial.css">
</head>

<body>
    <div class="background">
        <div class="bolinha bolinha1"></div>
        <div class="bolinha bolinha2"></div>
        <div class="bolinha bolinha3"></div>
        <div class="bolinha bolinha4"></div>
        <div class="bolinha bolinha5"></div>
        <div class="bolinha bolinha6"></div>

        <div class="logoCantoInferior">
            <img src="/imgFy/logoSemfundoEscritaBranca.png" alt="Logo">
        </div>

        <div class="logoWhatsApp">
            <img src="/imgFy/whatsapp (3).png" alt="logoWhatsApp">
        </div>
        
        <div class="fundoSemiTransparente">

            <div class="main-content-grid">

                <div class="navBar">
                    <nav>
                        <ul class="navbar-nav">
                            <li class="nav-item">
                                <a href="/client" class="active">Home</a>
                            </li>
                            <li class="nav-item">
                                <a href="/client/menu/list">Nutricional</a>
                            </li>
                            <li class="nav-item">
                                <a href="/client/exercise/list">Treinos</a>
                            </li>
                        </ul>
                    </nav>
                </div>

                <div class="profile-box-container">
                    <div class="cardVerPerfil"></a></div>
                    <div class="textocardVerPerfil"><a href="/client/cadastro" class="profile-link"> Ver perfil</a></div>
                </div>

                <div class="calendar-api-container">
                    <iframe class="frame_agenda" src="https://calendar.google.com/calendar/embed?height=600&wkst=1&ctz=America%2FSao_Paulo&showPrint=0&mode=WEEK&src=dGhhdWFuYWZleXRoMzRAZ21haWwuY29t&src=cHQuYnJhemlsaWFuI2hvbGlkYXlAZ3JvdXAudi5jYWxlbmRhci5nb29nbGUuY29t&src=ZW4uYnJhemlsaWFuI2hvbGlkYXlAZ3JvdXAudi5jYWxlbmRhci5nb29nbGUuY29t&color=%23039be5&color=%230b8043&color=%230b8043%22" 
                        style="border-width:0" 
                        width="100%" height="100%" 
                        frameborder="0" 
                        scrolling="no">
                    </iframe>
                </div>
                <div class="cardMetaPeso">
                    <h3 class="titulo_peso"> Progresso Meta de Peso</h3>
                </div>

                <div class="cardProgressoMetaPeso">
                    <h3 class="titulo_percentual"> Percentuais </h3>
                </div>

                </div>
        </div>
    </div>
</body>

</html>